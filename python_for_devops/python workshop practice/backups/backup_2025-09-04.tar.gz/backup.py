import shutil
import datetime
import os

def backup_files(source, destination):
    today = datetime.date.today()
    backup_file_name = os.path.join(destination, f"backup_{today}")
    # make_archive automatically adds .tar.gz
    shutil.make_archive(backup_file_name, 'gztar', source)

# ---- function call ----
source = "/home/a/Desktop/Devops-Journey/python workshop practice"
destination = "/home/a/Desktop/Devops-Journey/python workshop practice/backups"

backup_files(source, destination)
print("Backup created successfully!")
