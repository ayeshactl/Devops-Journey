import os #importing a library into your code.

print(os.system('df -h')) #linuc or mac
print(os.system('uptime')) #uptime and load average
print(os.system('free -h')) #RAM