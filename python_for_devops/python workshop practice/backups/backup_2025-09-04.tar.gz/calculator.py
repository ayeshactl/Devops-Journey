num1 = int(input("Enter num one: ")) #str -> int "type casting"
num2 = int(input("Enter num two: "))

print(type(num1))
print(type(num2))
sum_of_num = num1 + num2

print("Sum of 2 numbers: ",sum_of_num)


diff_of_num = num1 - num2
print("Diff of 2 numbers: ",diff_of_num)


product_of_num = num1 * num2
print("Product of 2 numbers: ",product_of_num)


division_of_num = num1 * num2
print("Division of 2 numbers: ",division_of_num)