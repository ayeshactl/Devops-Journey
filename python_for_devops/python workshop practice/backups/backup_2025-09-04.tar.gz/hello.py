
name = input("enter your name:") #user se input le skte ho
name = "harsh"  #variable = vary ho skta hai, vari + able
env = "dev"   #dev = constant, env = variable
print("Hello",name)